python -u main.py -i "/workspace/inputs/"  -o "/workspace/outputs/" --workers 0
