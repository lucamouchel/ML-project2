docker save cells | gzip -1 -c > cells.tar.gz
