docker run cells -m 28G --name cells --rm cells:latest /bin/bash -c "sh predict.sh"
