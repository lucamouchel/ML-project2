docker build --tag cells .
